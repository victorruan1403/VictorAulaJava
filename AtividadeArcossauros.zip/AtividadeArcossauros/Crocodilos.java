package AtividadeArcossauros;

public class Crocodilos extends Arcossauro {
    @Override
    public void mostrarCaracteristicas() {
        System.out.println("Crocodilos são arcossauros atuais que vivem em ambientes aquáticos.");
    }
}
