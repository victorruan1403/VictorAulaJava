package AtividadeArcossauros;

public class Saurísquios extends Dinossauros{
    @Override
    public void mostrarCaracteristicas(){
        System.out.println("Saurísquios são um grupo de dinossauros que inclui os terópodes e os sauropodomorfos.");
    }

}
