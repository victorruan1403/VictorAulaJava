package AtividadeArcossauros;

public class Main {
    public static void main(String[] args) {
       Arcossauro a1 = new Tecodontes();
       Arcossauro a2 = new Pterossauros();
       Arcossauro a3 = new Crocodilos();
       Arcossauro a4 = new Dinossauros();

        System.out.println("Características dos Arcossauros:");
        System.out.println("-----------------------------");
        System.out.println("Tecodentes:  ");
         a1.mostrarCaracteristicas();

        System.out.println("--------------------");
        System.out.println("Pterossauros:  ");
        a2.mostrarCaracteristicas();

        System.out.println("--------------------");
        System.out.println("Crocodilos:  ");
        a3.mostrarCaracteristicas();

        System.out.println("--------------------");
        System.out.println("Dinossauros:  ");
        a4.mostrarCaracteristicas();






    }
}
