package AtividadeArcossauros;

public class Pterossauros extends Arcossauro {
    @Override
    public void mostrarCaracteristicas() {
        System.out.println("Pterossauros eram répteis voadores que viveram na era dos dinossauros.");
    }
}