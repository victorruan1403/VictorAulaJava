package AtividadeArcossauros;

public class Tecodontes extends Arcossauro {
    @Override
    public void mostrarCaracteristicas(){
        System.out.println("Tecodontes são arcossauros primitivos, acestrais dos dinossauros.");
    }
}
