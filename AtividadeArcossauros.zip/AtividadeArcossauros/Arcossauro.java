package AtividadeArcossauros;

public class Arcossauro {
    public void mostrarCaracteristicas(){
        System.out.println("Os arcossauros são um grupo de répteis que incluem arcossauros, crocodilos e aves.");
    }
}
