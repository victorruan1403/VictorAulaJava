package AtividadeArcossauros;

public class Dinossauros extends Arcossauro {
    @Override
    public void mostrarCaracteristicas(){
        System.out.println("Dinossauros são arcoassauros que dominaram a terra no periodo Mesozoico.");





    }
}
