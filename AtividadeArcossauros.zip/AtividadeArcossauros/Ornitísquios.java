package AtividadeArcossauros;

public class Ornitísquios extends Dinossauros {
    @Override
    public void mostrarCaracteristicas(){
        System.out.println("Ornitísquios são um grupo de dinossauros herbívoros que inclui os ceratopsianos e os hadrossauros.");
    }
}
